from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
from .forms import login_form, Registration_form
from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate, login
from django.http import JsonResponse

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
import joblib
import json

# Create your views here.

def index(request):
    return render(request,'home.html')
def products(request):
    dict_meds = {
        'meds': Medicines.objects.all()
    }
    return render(request, 'products.html', dict_meds)

def cart(request):

    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(customer=customer, complete=False)
        items = order.orderditem_set.all()
    else:
        items = []
        order = {'get_cart_total': 0, 'get_cart_items': 0}

    context = {'items': items, 'order': order}
    return render(request, 'cart.html', context)

def checkout(request):
    return render(request, 'checkout.html')


def login(request):
    form = login_form(request.POST or None)
    context = {
        'form': form
    }
    if form.is_valid():
        print(form.cleaned_data)
        username = form.cleaned_data.get('Username')
        password = form.cleaned_data.get('Password')
        user = authenticate(request, username='Username', password='Password')
        if user is not None:
            login(request, user)
            return redirect('home.html')
    else:
        print('error')
    return render(request, 'login.html', context)

User= get_user_model()
def Registration(request):
    form = Registration_form(request.POST or None )
    context = {
        'form': form
    }
    if form.is_valid():
        print(form.cleaned_data)
        username = form.cleaned_data.get('Username')
        email = form.cleaned_data.get('Email')
        password = form.cleaned_data.get('Password')
        new_user = User.objects.create_user(username, email, password)
        print(new_user)
    return render(request, 'reg.html', context)
def result(request):
    data = pd.read_csv('diabetes.csv')
    print(data.head())

    logreg = LogisticRegression()
    X = data.iloc[:, :8]
    print(X.shape[1])
    y = data[["Outcome"]]
    X = np.array(X)
    y = np.array(y)
    logreg.fit(X, y.reshape(-1, ))
    joblib.dump(logreg, "result2")
    return render(request, 'diet.html')

def updateItem(request):
    data = json.loads(request.body)

    productId = data['productId']
    action = data['action']

    print('Action', action)
    print('productid', productId)

    customer = request.user.customer
    product = Medicines.objects.get(id=productId)


    order, created = Order.objects.get_or_create(customer=customer, complete=False)

    orderItem, created = OrderdItem.objects.get_or_create(order=Order, product=product)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)
    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse("item added to cart", safe=False)
