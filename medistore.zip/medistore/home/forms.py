
from django import forms



class login_form(forms.Form):
    Username = forms.CharField()
    Password = forms.CharField()
class Registration_form(forms.Form):
    Username = forms.CharField()
    Email = forms.EmailField()
    Password = forms.CharField(widget=forms.PasswordInput)
    Password2 = forms.CharField(label='Re enter password', widget=forms.PasswordInput)

